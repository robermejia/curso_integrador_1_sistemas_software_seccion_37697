package com.utp.technology.http.dto.user;

import lombok.Data;

@Data
public class UserListDtoImpl implements UserListDto {

  private Long id;
  private Integer idRol;
  private String correo;
  private String nombre;

}
