package com.utp.technology.http.dto.cliente;

import lombok.Data;

@Data
public class ListClienteDtoImpl implements ListClienteDto {

  private Integer id;
  private String nombre;
  private String apellido;
  private String dni;
  private String telefono;
  private String correo;

}
