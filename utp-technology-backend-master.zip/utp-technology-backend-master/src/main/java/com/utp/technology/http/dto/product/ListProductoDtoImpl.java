package com.utp.technology.http.dto.product;

import lombok.Data;

@Data
public class ListProductoDtoImpl implements ListProductoDto {

  private Integer id;
  private String nombre;
  private String imagen;
  private Double precio;
  private Integer stock;

}
