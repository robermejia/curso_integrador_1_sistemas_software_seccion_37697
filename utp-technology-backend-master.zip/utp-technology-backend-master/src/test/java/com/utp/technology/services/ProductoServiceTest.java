package com.utp.technology.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;

import com.utp.technology.http.dto.product.ListProductoDto;
import com.utp.technology.http.dto.product.ListProductoDtoImpl;
import com.utp.technology.http.dto.product.StoreProductDTO;
import com.utp.technology.model.Producto;
import com.utp.technology.repository.ProductoRepository;
import com.utp.technology.services.impl.ProductoServiceImpl;

@ExtendWith(MockitoExtension.class)
public class ProductoServiceTest {

  @Mock
  private ProductoRepository productoRepository;

  @InjectMocks
  private ProductoServiceImpl productoService;

  private ListProductoDto producto;
  private Producto productoModel;
  private Pageable pageable;

  @BeforeEach
  void setUp() {
    var productoTest = new ListProductoDtoImpl();
    productoTest.setId(1);
    productoTest.setNombre("");
    productoTest.setImagen("");
    productoTest.setPrecio(0.0);
    productoTest.setStock(0);
    this.producto = productoTest;

    productoModel = new Producto();
    productoModel.setId(1);
    productoModel.setNombre("");
    productoModel.setImagen("");
    productoModel.setPrecio(0.0);
    productoModel.setStock(0);

    pageable = PageRequest.of(0, 10, Sort.by(Direction.ASC, "id"));
    this.productoService = new ProductoServiceImpl(productoRepository);
  }

  @Test
  void listarProductos() {
    String nombreBusqueda = null;
    List<ListProductoDto> productos = Collections.singletonList(producto);
    Page<ListProductoDto> productoPage = new PageImpl<>(productos, pageable, 1);

    when(productoRepository.listProducto(eq(nombreBusqueda), any(Pageable.class))).thenReturn(productoPage);

    Page<ListProductoDto> resultPage = productoService.listAll(nombreBusqueda, pageable);
    // Validando que resultPage no sea null
    assertThat(resultPage).isNotNull();
    // Validando que el resultado tenga un tamaño de 1
    assertThat(resultPage.getContent()).hasSize(1);

    // Validando que el método fue correctamente invocado
    verify(productoRepository, times(1)).listProducto(eq(nombreBusqueda), any(Pageable.class));
  }

  @Test
  void guardarProducto() {
    when(productoRepository.save(any(Producto.class))).thenReturn(productoModel);

    StoreProductDTO dto = new StoreProductDTO(producto.getNombre(), producto.getImagen(), producto.getPrecio(),
        producto.getStock());
    Producto result = productoService.guardar(dto);
    assertThat(result).isNotNull();

    verify(productoRepository, times(1)).save(any(Producto.class));
  }

  @Test
  void editarProducto() {
    when(productoRepository.save(any(Producto.class))).thenReturn(productoModel);

    Producto result = productoService.editar(productoModel);
    assertThat(result).isNotNull();
    verify(productoRepository, times(1)).save(any(Producto.class));
  }

  @Test
  void eliminarProducto() {
    productoService.eliminar(productoModel);
    verify(productoRepository, times(1)).delete(any(Producto.class));
  }
}
