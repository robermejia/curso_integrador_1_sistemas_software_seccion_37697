package com.utp.technology.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.utp.technology.http.dto.auth.SignUpRequestDTO;
import com.utp.technology.http.dto.user.UserListDto;
import com.utp.technology.http.dto.user.UserListDtoImpl;
import com.utp.technology.model.Cliente;
import com.utp.technology.model.Rol;
import com.utp.technology.model.Usuario;
import com.utp.technology.repository.ClienteRepository;
import com.utp.technology.repository.UsuarioRepository;
import com.utp.technology.services.impl.UsuarioServiceImpl;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

  @Mock
  private UsuarioRepository usuarioRepository;

  @Mock
  private ClienteRepository clienteRepository;

  @Mock
  private PasswordEncoder passwordEncoder;

  @InjectMocks
  private UsuarioServiceImpl usuarioService;

  UserListDto userDto;
  Usuario userModel;
  Cliente cliente;

  @BeforeEach
  void setUp() {
    UserListDtoImpl userDto = new UserListDtoImpl();
    userDto.setId(0L);
    userDto.setNombre("");
    userDto.setCorreo("correo@gmail.com");
    userDto.setIdRol(0);
    this.userDto = userDto;

    this.userModel = new Usuario();
    this.userModel.setId(0);
    this.userModel.setClave("123456");
    this.userModel.setCorreo("");
    this.userModel.setNombre("");

    this.cliente = new Cliente();
    this.cliente.setId(1);
    this.cliente.setApellido("");
    this.cliente.setCorreo("");
    this.cliente.setApellido("");
    this.cliente.setDni("");

    Rol rol = new Rol();
    rol.setIdRol(0);
    this.userModel.setRol(rol);
  }

  @Test
  void testListAll() {
    when(usuarioRepository.listAll()).thenReturn(Collections.singletonList(userDto));

    List<UserListDto> result = usuarioService.listAll();

    assertThat(result).isNotNull();
    assertThat(result).hasSize(1);

    verify(usuarioRepository, times(1)).listAll();
  }

  @Test
  void testFindById() {
    Integer userId = 0;
    when(usuarioRepository.findById(eq(userId))).thenReturn(Optional.of(userModel));

    Optional<Usuario> usuarioOpt = usuarioRepository.findById(userId);

    assertThat(usuarioOpt.isPresent()).isEqualTo(true);

    verify(usuarioRepository, times(1)).findById(userId);
  }

  @Test
  void testFindByCorreo() {
    String userCorreo = userModel.getCorreo();
    when(usuarioRepository.findByCorreo(eq(userCorreo))).thenReturn(Optional.of(userModel));

    Optional<Usuario> usuarioOpt = usuarioRepository.findByCorreo(userCorreo);

    assertThat(usuarioOpt.isPresent()).isEqualTo(true);
    assertThat(usuarioOpt.get().getCorreo()).isEqualTo(userModel.getCorreo());

    verify(usuarioRepository, times(1)).findByCorreo(userCorreo);
  }

  @Test
  void testRegistrarUsuarioNoExistente() {
    SignUpRequestDTO dto = new SignUpRequestDTO();
    dto.setDni("12345678");
    dto.setApellido("");
    dto.setEmail(userModel.getCorreo());
    dto.setNombre("");
    dto.setPassword("123456");
    dto.setTelefono("");

    when(clienteRepository.findByDni(eq(dto.getDni()))).thenReturn(Optional.empty());
    when(passwordEncoder.encode(eq(dto.getPassword()))).thenReturn(dto.getPassword());
    when(usuarioRepository.save(any(Usuario.class))).thenReturn(userModel);
    when(clienteRepository.save(any(Cliente.class))).thenReturn(cliente);

    Usuario result = this.usuarioService.registrarUsuario(dto);

    assertThat(result).isNotNull();
  }

}
